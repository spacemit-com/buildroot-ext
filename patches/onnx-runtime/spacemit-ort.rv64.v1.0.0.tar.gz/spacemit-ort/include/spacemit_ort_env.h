// Copyright (c) 2023 SpacemiT. All rights reserved.

#pragma once
#include <string>
#include <unordered_map>

#include "onnxruntime_cxx_api.h"

namespace Ort {
Status SessionOptionsSpaceMITEnvInit(SessionOptions& options,
                                     const std::unordered_map<std::string, std::string> provider_options = {});

}  // namespace Ort
