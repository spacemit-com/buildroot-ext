// Copyright (c) 2023 SpacemiT. All rights reserved.

#pragma once

#include "onnxruntime_c_api.h"

#ifdef __cplusplus
extern "C" {
#endif

ORT_EXPORT OrtStatus* ORT_API_CALL OrtSessionOptionsSpaceMITEnvInit(
    OrtSessionOptions* options, _In_reads_(num_keys) const char* const* provider_options_keys,
    _In_reads_(num_keys) const char* const* provider_options_values, size_t num_keys);

#ifdef __cplusplus
}
#endif
